#include "modelTan.h"
int main()
{
	modelTan *tan = new modelTan(72,1);
	tan->getHoraires();
	return 0;
}